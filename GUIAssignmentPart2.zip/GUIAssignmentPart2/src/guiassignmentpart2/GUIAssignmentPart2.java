package guiassignmentpart2;

import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Event;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class GUIAssignmentPart2 extends JFrame implements ActionListener{

    private JLabel lable1, lable2;
    private JRadioButton radio;
    private JRadioButton radio2;
    private JTextField textfield;
    private final JLabel lable3;
    private final JLabel lblWelcome;
    private final JLabel lblWelcome2;



    public GUIAssignmentPart2(String title){
        super(title);
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        lable1 = new JLabel("Enter Celsius temperature:");
        textfield = new JTextField(25);
        
        ButtonGroup group = new ButtonGroup();
        lblWelcome2 = new JLabel("                        ", SwingConstants.CENTER);
        radio = new JRadioButton("Fehrenheit");
        radio2 = new JRadioButton("Kelvin");
        

        lblWelcome = new JLabel("                              ", SwingConstants.CENTER);
        
        lable2 = new JLabel("New Temperature in is:");
        lable3 = new JLabel("");
        group.add(radio);
        group.add(radio2);
        panel.add(lable1);
        panel.add(textfield);
        panel.add(lblWelcome2);
        panel.add(radio);
        radio.addActionListener(this);
        panel.add(radio2);
        radio2.addActionListener(this);
        panel.add(lblWelcome);
        panel.add(lable2);
        panel.add(lable3);
        
        this.add(panel);
        
        this.setSize(350, 150);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }
    
    public static void main(String[] args) {
        GUIAssignmentPart2 gui2 = new GUIAssignmentPart2("Temperature converter");
        
    }

    @Override
   public void actionPerformed(ActionEvent e) {
       String text=textfield.getText();
       int degree=Integer.parseInt(text);
       String degreeinfe=String.valueOf(degree* 9/5 + 32) ;
       String degreeinke=String.valueOf(degree+273.15) ;
       
       
        if(e.getSource().equals(radio)){
            lable3.setText(degreeinfe);
        }else if(e.getSource().equals(radio2)){
            lable3.setText(degreeinke);
        }

    }
    
}


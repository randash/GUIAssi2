package guiassignmentpart2;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import javax.swing.JFrame;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JRadioButton;
import javax.swing.JSlider;
import javax.swing.border.LineBorder;
import javax.swing.event.ChangeListener;

public class GUIasi4 extends JFrame {

    private JLabel labelName, labelPassword;
    private JPasswordField textFieldPassword;
    private JTextField textFieldName;
    private JButton buttonOK, buttonCancel;
    private JPanel panelLogin;
    private JTextArea textArea;
    private JScrollPane scrollPane;
    private JCheckBox checkBox, checkBox2;
    private JLabel lable;
    private JComboBox combo;
    private JRadioButton radio;
    private JRadioButton radio2;

    public GUIasi4() {
        setLayout(null);
        JMenuBar bar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");// fileMenu.setMnemonic( 'F' );
        JMenu formatMenu = new JMenu("Edit");

        JMenuItem AboutItem = new JMenuItem("Open", 'O');
        fileMenu.add(AboutItem);
        AboutItem.addActionListener(new ActionListener() {
            private Component jfrm;

            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fc = new JFileChooser();
                fc.setCurrentDirectory(new File("."));
                fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
//int result = fc.showOpenDialog(jfrm);
                int result = fc.showDialog(jfrm, "Select");
//int result = fc.showSaveDialog(jfrm);
//int result = fc.showDialog(jfrm, "Save"); 	
                String filename = fc.getSelectedFile().getPath();
                try {
                    BufferedReader in;
                    in = new BufferedReader(new FileReader(filename));
                    String line = in.readLine();
                    while (line != null) {
                        textArea.setText(textArea.getText() + "\n" + line);
                        line = in.readLine();
                    }
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(GUIasi4.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IOException ex) {
                    Logger.getLogger(GUIasi4.class.getName()).log(Level.SEVERE, null, ex);
                }

            }

        }
    );
        JMenuItem closeItem = new JMenuItem("Close", 'C');

    fileMenu.add (closeItem);

    closeItem.addActionListener ( 
        new ActionListener() {
            @Override
        public void actionPerformed
        (ActionEvent e
        
            ) {
                textArea.setText("");
            textArea.setEditable(false);
        }
    }
    );
        JMenuItem ExitItem = new JMenuItem("Exit", 'E');

    fileMenu.add (ExitItem);

    ExitItem.addActionListener ( 
        new ActionListener() {
            @Override
        public void actionPerformed
        (ActionEvent e
        
            ) {
                System.exit(0);
        }
    }
    );

        JMenuItem fontItem = new JMenuItem("Font", 'F');

    formatMenu.add (fontItem);

    fontItem.addActionListener ( 
        new ActionListener() {
            @Override
        public void actionPerformed
        (ActionEvent e
        
            ) {
                // JOptionPane.showMessageDialog(null,);

//                JComboBox size = new JComboBox();
//                size.setEditable(true);
//                for(int i=1;i<30;i++){
//                size.addItem(i);
                // }
                Object s
                    = JOptionPane.showInputDialog(
                            null,
                            "font size",
                            "choose",
                            JOptionPane.WARNING_MESSAGE,
                            null, //icon object
                            new String[]{"12", "14", "16", "18", "20", "22", "24", "26"}, //list  items
                            "16" //defalut selected item in the list
                    );
            // textArea.getText().
            String str = (String) s;

            textArea.setFont(new Font("Serif", Font.PLAIN, Integer.parseInt(str)));

        }
    }
    );
        JMenuItem colorItem = new JMenuItem("Color", 'C');

    formatMenu.add (colorItem);

    colorItem.addActionListener ( 
        new ActionListener() {
            @Override
        public void actionPerformed
        (ActionEvent e
        
            ) {
                Color selectedColor = JColorChooser.showDialog(null, "choose color", Color.PINK);
            textArea.setForeground(selectedColor);
        }
    }
    );

        scrollPane  = new JScrollPane();

    scrollPane.setVerticalScrollBarPolicy (JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

    scrollPane.setHorizontalScrollBarPolicy (JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

    textArea  = new JTextArea();

    textArea.setBounds (

    20, 20, 500, 400);

    textArea.setBorder (

    new LineBorder(Color.black));

    scrollPane.setBounds (

    20, 20, 500, 400);
    scrollPane.getViewport ()

    .setBackground(Color.white);
    scrollPane.getViewport ()

    .add(textArea);
    add(scrollPane);

    bar.add (fileMenu);

    bar.add (formatMenu);

     

    this.setJMenuBar(bar);

    //add(textArea);
     

    this.setSize(
    600, 550);
         

    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     

    this.setVisible(

true);

    }

    public static void main(String[] args) {
        GUIasi4 g = new GUIasi4();
    }

}

package guiassignmentpart2;

import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Event;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class GUIasi3 extends JFrame{

    private JLabel lable1, lable2;
    private JRadioButton radio;
    private JRadioButton radio2;
    private JTextField textfield;
    private JLabel lable3;
    private JLabel lblWelcome;
    private JLabel lblWelcome2;
    private final JPanel panelLogin;
    private JButton button;
    
    private final JLabel lbl;
    private final JLabel lb2;
    
    static int number=(int)(Math.random() * 1000);
    
    public GUIasi3(String title) {
        super(title);
        panelLogin = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panelLogin.setBackground(Color.white);
        lable1=new JLabel("I have a number between 1 and 1000.");
        lbl = new JLabel("can you guess my number? ", SwingConstants.CENTER);
        lb2 = new JLabel("                Too high.try a lower number.         ", SwingConstants.CENTER);
        textfield=new JTextField("",5);
        textfield.setEditable(true);
//        textfield.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                
//            }
//        });
        textfield.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent event) {
               
                if(textfield.getText().isEmpty()){
                    //return;
                }else{
                 int key=Integer.parseInt(textfield.getText());
               
             if(key>number+20){
                 //blue
                lb2.setText("          Too high.try a lower number. ");
                panelLogin.setBackground(Color.blue);
                
             }else if(key==number){
                 //correct
                 lb2.setText("correct! ");
                 textfield.setEditable(false);
                 
                 
             }else if(key+20<number){
                 //blue
                 lb2.setText("          Too low.try a higher number. ");
                 panelLogin.setBackground(Color.blue);
             }
             else if((key>number-20&& key<number)){
                 //red
                 lb2.setText("          your getting warmer... ");
                 panelLogin.setBackground(Color.red);
             }
             else if((key>number&&key<number+20)){
                 //red
                 lb2.setText("          your getting warmer... ");
                 panelLogin.setBackground(Color.red);
             }
             
            }
                
                
                
                
                
                
                

            }
        }
        );
        
        
        button=new JButton("New Game");
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              number=(int)(Math.random() * 1000);
                System.out.println(number);
               textfield.setEditable(true);
            }
        });
        panelLogin.add(lable1);
         // panelLogin.add(lable2);
           panelLogin.add(lbl);
          panelLogin.add(lb2);
         // panelLogin.add(lable3);
          panelLogin.add(textfield);
          panelLogin.add(button);
        this.add(panelLogin);
        this.setSize(350, 150);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
        
    }
    
    

    public static void main(String[] args) {
        GUIasi3 gui=new GUIasi3("Guessing Game");
        System.out.println(number);

    }

}
